<?php require_once( 'couch/cms.php' ); ?>
<cms:template title='Conditional Fields Test' >
    <cms:editable 
        type='checkbox' 
        name='previous_work_experience' 
        label='Any previous employment experience?' 
        opt_values='Yes' 
    />

    <cms:func _into='my_cond' previous_work_experience=''>
        <cms:if "<cms:is 'Yes' in=previous_work_experience />">show<cms:else />hide</cms:if>
    </cms:func>
    <cms:editable 
        type='dropdown' 
        name='previous_number_of_employers' 
        label='Please select the number of places you have been previously employed' 
        opt_values='Please indicate=- | One | Two | Three' 
        required='1'
        not_active=my_cond
    />
    
    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
        <cms:if 
            "<cms:is 'Yes' in=previous_work_experience />" 
            && 
            (previous_number_of_employers='One' || previous_number_of_employers='Two' || previous_number_of_employers='Three')
        >
            show
        <cms:else />
            hide
        </cms:if>
    </cms:func>
    <cms:editable name='previous_employer1' type='row'>
        <cms:editable name='previous_employer1_name' label='Employer Name (1)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer1_phone' label='Employer Phone (1)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer1_email' label='Employer Email (1)' type='text' required='1' class='col-md-4' not_active=my_cond />
    </cms:editable>
    
    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
        <cms:if 
            "<cms:is 'Yes' in=previous_work_experience />" 
            && 
            (previous_number_of_employers='Two' || previous_number_of_employers='Three')
        >
            show
        <cms:else />
            hide
        </cms:if>
    </cms:func>
    <cms:editable name='previous_employer2' type='row'>
        <cms:editable name='previous_employer2_name' label='Employer Name (2)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer2_phone' label='Employer Phone (2)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer2_email' label='Employer Email (2)' type='text' required='1' class='col-md-4' not_active=my_cond />
    </cms:editable>
    
    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
        <cms:if "<cms:is 'Yes' in=previous_work_experience />" && previous_number_of_employers='Three'>
            show
        <cms:else />
            hide
        </cms:if>
    </cms:func>
    <cms:editable name='previous_employer3' type='row'>
        <cms:editable name='previous_employer3_name' label='Employer Name (3)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer3_phone' label='Employer Phone (3)' type='text' required='1' class='col-md-4' not_active=my_cond />
        <cms:editable name='previous_employer3_email' label='Employer Email (3)' type='text' required='1' class='col-md-4' not_active=my_cond />
    </cms:editable>
</cms:template>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Form</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        
        <script src="<cms:show k_admin_link/>includes/jquery-3.x.min.js?v=<cms:show k_cms_build />"></script>
        <style>
        input[type="text"], input[type="password"], textarea, select {
            max-width: 100%;
            height: 38px;
            padding: 8px;
            border: 1px solid #c0c0c0;
            border-radius: 3px;
            background-color: #fcfcfc;
            color: #444;
            font-family: inherit;
            font-size: 14px;
            box-shadow: none;
        }
        
        /* conditional fields */
#k_element_previous_number_of_employers, #k_element_previous_employer1_name, #k_element_previous_employer1_phone, #k_element_previous_employer1_email, #k_element_previous_employer2_name, #k_element_previous_employer2_phone, #k_element_previous_employer2_email, #k_element_previous_employer3_name, #k_element_previous_employer3_phone, #k_element_previous_employer3_email
{ display:none; }

        </style>
    </head>

    <body>
        <div class="row align-items-center mt-5">
            <div class="container col-8 col-offset-2">
            
            <!-- 
                After this template has been registered (is visible in admin-panel sidebar), you may
                remove tbe following <cms:ignore> and its closing </cms:ignore> tag below to activate the databound form.
            !-->
            <cms:ignore>
                <h4>DataBound Form</h4>
                <hr>

                <cms:set submit_success="<cms:get_flash 'submit_success' />" />
                <cms:if submit_success >
                    <div class="alert alert-success fade in show" style="margin-top:18px;">
                        <strong>Saved</strong>
                    </div>
                </cms:if>
    
                <cms:form
                    masterpage=k_template_name
                    mode='edit'
                    page_id=k_page_id
                    enctype='multipart/form-data'
                    method='post'
                    anchor='0'
                    >

                    <cms:if k_success >
                        <cms:db_persist_form />

                        <cms:if k_success >
                            <cms:set_flash name='submit_success' value='1' />
                            <cms:redirect k_page_link />
                        </cms:if>
                    </cms:if>

                    <cms:if k_error >
                        <div class="alert alert-danger fade in show">
                            <cms:each k_error >
                                <cms:show item /><br>
                            </cms:each>
                        </div>
                    </cms:if>

                    <div class="form-group">
                        <label>Any previous employment experience?</label> 
                        <div>
                            <cms:input name='previous_work_experience' type='bound' />
                        </div>
                    </div> 

                    <div class="form-group" id="k_element_previous_number_of_employers">
                        <label for="previous_number_of_employers">Please select the number of places you have been previously employed</label>
                        <div>
                            <cms:input name='previous_number_of_employers' type='bound' />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_name">
                            <label for="previous_employer1_name">Employer Name (1)</label>
                            <cms:input name='previous_employer1_name' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_phone">
                            <label for="previous_employer1_phone">Employer Phone (1)</label>
                            <cms:input name='previous_employer1_phone' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_email">
                            <label for="previous_employer1_email">Employer Email (1)</label>
                            <cms:input name='previous_employer1_email' type='bound' />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_name">
                            <label for="previous_employer2_name">Employer Name (2)</label>
                            <cms:input name='previous_employer2_name' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_phone">
                            <label for="previous_employer2_phone">Employer Phone (2)</label>
                            <cms:input name='previous_employer2_phone' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_email">
                            <label for="previous_employer2_email">Employer Email (2)</label>
                            <cms:input name='previous_employer2_email' type='bound' />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_name">
                            <label for="previous_employer3_name">Employer Name (3)</label>
                            <cms:input name='previous_employer3_name' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_phone">
                            <label for="previous_employer3_phone">Employer Phone (3)</label>
                            <cms:input name='previous_employer3_phone' type='bound' />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_email">
                            <label for="previous_employer3_email ">Employer Email (3)</label>
                            <cms:input name='previous_employer3_email' type='bound' />
                        </div>
                    </div>

                    <div class="form-group">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </cms:form>
            </cms:ignore>    
                
                <br>
                <h4>Regular Form</h4>
                <hr>
                
                <cms:set submit_success="<cms:get_flash 'submit_success2' />" />
                <cms:if submit_success >
                    <div class="alert alert-success fade in show" style="margin-top:18px;">
                        <strong>Saved</strong>
                    </div>
                </cms:if>

                <cms:form method='post' anchor='0'>
                    <cms:if k_success >
                        <!-- do something -->

                        <cms:if k_success >
                            <cms:set_flash name='submit_success2' value='1' />
                            <cms:redirect k_page_link />
                        </cms:if>
                    </cms:if>

                    <cms:if k_error >
                        <div class="alert alert-danger fade in show">
                            <cms:each k_error >
                                <cms:show item /><br>
                            </cms:each>
                        </div>
                    </cms:if>

                    <div class="form-group">
                        <label>Any previous employment experience?</label> 
                        <div>
                            <cms:input name="previous_work_experience" type="checkbox" opt_values="Yes" /> 
                        </div>
                    </div> 

                    <cms:func _into='my_cond' previous_work_experience=''>
                        <cms:if "<cms:is 'Yes' in=previous_work_experience />">show<cms:else />hide</cms:if>
                    </cms:func>

                    <div class="form-group" id="k_element_previous_number_of_employers">
                        <label for="previous_number_of_employers">Please select the number of places you have been previously employed</label>
                        <div>
                            <cms:input name="previous_number_of_employers" type="dropdown" opt_values='Please indicate=- | One | Two | Three' required='1' not_active=my_cond />
                        </div>
                    </div>

                    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
                        <cms:if 
                            "<cms:is 'Yes' in=previous_work_experience />" 
                            && 
                            (previous_number_of_employers='One' || previous_number_of_employers='Two' || previous_number_of_employers='Three')
                        >
                            show
                        <cms:else />
                            hide
                        </cms:if>
                    </cms:func>

                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_name">
                            <label for="previous_employer1_name">Employer Name (1)</label>
                            <cms:input name="previous_employer1_name" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_phone">
                            <label for="previous_employer1_phone">Employer Phone (1)</label>
                            <cms:input name="previous_employer1_phone" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer1_email">
                            <label for="previous_employer1_email">Employer Email (1)</label>
                            <cms:input name="previous_employer1_email" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                    </div>

                    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
                        <cms:if 
                            "<cms:is 'Yes' in=previous_work_experience />" 
                            && 
                            (previous_number_of_employers='Two' || previous_number_of_employers='Three')
                        >
                            show
                        <cms:else />
                            hide
                        </cms:if>
                    </cms:func>
    
                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_name">
                            <label for="previous_employer2_name">Employer Name (2)</label>
                            <cms:input name="previous_employer2_name" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_phone">
                            <label for="previous_employer2_phone">Employer Phone (2)</label>
                            <cms:input name="previous_employer2_phone" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer2_email">
                            <label for="previous_employer2_email">Employer Email (2)</label>
                            <cms:input name="previous_employer2_email" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                    </div>

                    <cms:func _into='my_cond' previous_work_experience='' previous_number_of_employers=''>
                        <cms:if "<cms:is 'Yes' in=previous_work_experience />" && previous_number_of_employers='Three'>
                            show
                        <cms:else />
                            hide
                        </cms:if>
                    </cms:func>
    
                    <div class="row">
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_name">
                            <label for="previous_employer3_name">Employer Name (3)</label>
                            <cms:input name="previous_employer3_name" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_phone">
                            <label for="previous_employer3_phone">Employer Phone (3)</label>
                            <cms:input name="previous_employer3_phone" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                        <div class="col-md-4 form-group" id="k_element_previous_employer3_email">
                            <label for="previous_employer3_email ">Employer Email (3)</label>
                            <cms:input name="previous_employer3_email" type="text" required='1' size='105' not_active=my_cond />
                        </div>
                    </div>

                    <div class="form-group">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </cms:form>
            </div>
        </div>
        <script type="text/javascript">
            //<![CDATA[
            <cms:conditional_js />
            //]]>
        </script>
    </body>
</html>
<?php COUCH::invoke(); ?>